(function () {
    let d = document;
    let modal = false;
    let mobileMenu = false;
    let mobHeaderShown = false;
    const openMenuElement = document.querySelector('#open-menu');

    openMenuElement.addEventListener('click', () => {
        if (modal) {
            toggleModal();
            return;
        }

        toggleMenu();
    });

    const openModalElements = document.querySelectorAll('.modal_btn');

    [].forEach.call(openModalElements, function (el) {
        el.addEventListener('click', (e) => {
            e.preventDefault();
            toggleModal(Boolean(e.target.dataset.keep_header));
        })
    });

    function toggleModal(keepHeader = false) {
        if (mobileMenu) {
            toggleMenu();
        }

        d.getElementsByTagName('body')[0].classList.toggle('modal');

        if (!keepHeader) {
            d.getElementById('site-header').classList.toggle('full');
        }

        // if(window.innerWidth > 767)
        //     d.querySelector('.site-header__content:not(.site-header__content--fixed)')
        //         .classList.toggle('hidden');

        d.getElementById('site-header-mobile').classList.add('full');
        d.getElementById('modal-wrapper').classList.toggle('open');
        d.getElementById('open-menu').classList.toggle('close');

        let headerButtons = d.getElementsByClassName('header--btn');

        modal = !modal;

        if (headerButtons.length > 0) {
            let modalBtnOpenText = headerButtons[0].dataset.openText;
            let modalBtnCloseText = headerButtons[0].dataset.close;
            headerButtons[0].classList.toggle('btn--inverted');
            headerButtons[0].innerHTML = modal ? modalBtnCloseText : modalBtnOpenText;
        }
    }


    function toggleMenu(e) {
        openMenuElement.classList.toggle('close');
        d.getElementsByTagName('body')[0].classList.toggle('modal');
        d.getElementById('mobile-menu').classList.toggle('opened');
        d.getElementsByClassName('site-header--mobile')[0].classList.add('full');
        mobileMenu = !mobileMenu;
    }
})();
