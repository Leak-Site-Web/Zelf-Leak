var configuration = null;
readTextFile("/configuration.json", LoadConfig);

function LoadConfig(text){
    let data = JSON.parse(text);
    configuration = {};
    for(var k in data){
        Object.defineProperty(configuration, k, {
            value: data[k],
            writable: false,
            configurable: false
        });
    }
    SetReferalLinks();
    SetupGtm();
}

function SetReferalLinks(){
    let x = document.querySelectorAll('li > a');

    for (let i = 0; i < x.length; i++) {
        if(!x[i].dataset.messenger) {
            continue;
        }

        if (x[i].dataset.messenger.indexOf("telegram") >= 0) {
            x[i].href = configuration["messengers"]["telegram"];
        } else if (x[i].dataset.messenger.indexOf("messenger") >= 0) {
            x[i].href = configuration["messengers"]["messenger"]
                .replace("fb-messenger-public://user-thread/", "https://m.me/");
        } else if (x[i].dataset.messenger.indexOf("whatsapp") >= 0) {
            x[i].href = configuration["messengers"]["whatsapp"];
        } else if (x[i].dataset.messenger.indexOf("viber") >= 0) {
            x[i].href = configuration["messengers"]["viber"];
        } else if (x[i].dataset.messenger.indexOf("discord") >= 0) {
            x[i].href = configuration["messengers"]["discord"];
        }
    }
}

function SetupGtm(){
    let tracking_id = configuration["gtm"]["tracking_id"];

    if(!tracking_id)
        return true;

    (function(w,d,s,l,i){
        w[l]=w[l]||[];
        w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});
        var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),
            dl=l!='dataLayer'?'&l='+l:'';
        j.async=true;
        j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
     })(window,document,'script','dataLayer', tracking_id);
}

function readTextFile(file, callback) {
    var rawFile = new XMLHttpRequest();
    rawFile.overrideMimeType("application/json");
    rawFile.open("GET", file, true);
    rawFile.onreadystatechange = function() {
        if (rawFile.readyState === 4 && rawFile.status == "200") {
            callback(rawFile.responseText);
        }
    }
    rawFile.send(null);
}



