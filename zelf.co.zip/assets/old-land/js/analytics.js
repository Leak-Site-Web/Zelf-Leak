(function () {
    let d = document;

    function AwaitConfig(){
        if(!!configuration){
            GetShortCode();
        }else{
          setTimeout(function() {
            AwaitConfig()
          }, 100)
        }
      }
      

    d.addEventListener('DOMContentLoaded', () => {
        AwaitConfig();
    });


    function GetShortCode(){
        if(!configuration["gtm"]["link"]){
            console.log("Failed to get the configuration");
            return false;
        }

        var xhr = new XMLHttpRequest();
        xhr.open("POST", configuration["gtm"]["link"], true)
        xhr.setRequestHeader('Content-type', 'application/json; charset=utf-8');    
        xhr.onreadystatechange = function(){
            if (xhr.readyState == 4) {
                if(xhr.status == 200) {
                    var shortCode = JSON.parse( xhr.responseText );
                    UpdateReferalLinks(shortCode.code);
                }
                else{
                    console.log("POST analytics response status:", xhr.status);
                }
             }
        }
        
        xhr.send(GetGtmBodyData());
    }


    function UpdateReferalLinks(shortCode){
        let x = d.querySelectorAll('li > a');
        for (i = 0; i < x.length; i++) {
             if(!x[i].dataset.messenger)
                continue;
             if(x[i].dataset.messenger.indexOf("telegram") >= 0){
                 x[i].href+="&start=" + shortCode; 
             }else if(x[i].dataset.messenger.indexOf("messenger") >= 0){
                 x[i].href+="?ref="+ shortCode; 
             }else if(x[i].dataset.messenger.indexOf("whatsapp") >= 0){
                let text =x[i].dataset.text;
                x[i].href+= text + shortCode + ")";
             }else if(x[i].dataset.messenger.indexOf("viber") >= 0){
                 x[i].href+="&context="+ shortCode; 
             }
           }
     }


    function getCookie(name) {
        let matches = d.cookie.match(new RegExp(
          "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
        ));
        return matches ? decodeURIComponent(matches[1]) : undefined;
    }

    function getParameterByName(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, '\\$&');
        var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, ' '));
    }

    function GetGtmBodyData(){
        let _domain = window.location.hostname;
        if(_domain.split(".").length > 2){
            _domain = _domain.substr(_domain.indexOf(".")+1);
        }
        let _rd = getCookie('referral_data');

        var shared_code = d.getElementById("shared_code");
        if(!!shared_code){
            let json = JSON.stringify({
                page_host: window.location.hostname,
                channel: "invite",
                referer: d.referrer,
                language: d.documentElement.getAttribute("lang"),
                ga_client_id: getCookie('_ga'),
                utm_source: getParameterByName('utm_source'),
                utm_medium: getParameterByName('utm_medium'),
                utm_campaign: getParameterByName('utm_campaign'),
                utm_term: getParameterByName('utm_term'),
                utm_content: getParameterByName('utm_content'),
                fbclid: getParameterByName('fbclid'),
                fbc: getCookie('_fbc'),
                fbp: getCookie('_fbp'),
                invite_code: shared_code.dataset.code 
              });
              return json; 
        }

         if(!!d.referrer && d.referrer.indexOf(_domain) != -1 && !!_rd){
            let referral = JSON.parse( window.atob( _rd ));

            let json = JSON.stringify({
                page_host: window.location.hostname,
                channel: referral["channel"],
                referer: referral["referer"],
                language: d.documentElement.getAttribute("lang"),
                ga_client_id: getCookie('_ga'),
                utm_source: referral["utm_source"] || getParameterByName('utm_source'),
                utm_medium:  referral["utm_medium"] || getParameterByName('utm_medium'),
                utm_campaign:  referral["utm_campaign"] || getParameterByName('utm_campaign'),
                utm_term:  referral["utm_term"] ||getParameterByName('utm_term'),
                utm_content:  referral["utm_content"] || getParameterByName('utm_content'),
                fbclid: getParameterByName('fbclid'),
                fbc: getCookie('_fbc'),
                fbp: getCookie('_fbp'),
                invite_code: referral["invite_code"] 
              });
              return json;
        }


        let json = JSON.stringify({
            page_host: window.location.hostname,
            channel: 'site',
            referer: d.referrer,
            language: d.documentElement.getAttribute("lang"),
            ga_client_id: getCookie('_ga'),
            utm_source: getParameterByName('utm_source'),
            utm_medium: getParameterByName('utm_medium'),
            utm_campaign: getParameterByName('utm_campaign'),
            utm_term: getParameterByName('utm_term'),
            utm_content: getParameterByName('utm_content'),
            fbclid: getParameterByName('fbclid'),
            fbc: getCookie('_fbc'),
            fbp: getCookie('_fbp'),
            invite_code: getCookie('shared_code')
          });

          return json;
    }




})();
