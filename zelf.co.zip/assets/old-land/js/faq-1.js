(function () {
    'use strict';

    const DEFAULT_CATEGORY = 'card';
    const ACTIVE_TAB_CLASS_NAME = 'tabs__item--active';
    const CATEGORIES = new Set(['card', 'security', 'payments', 'account', 'junior', 'nft', 'playToEarn', 'about', 'contacts']);

    const tabsElement = document.querySelector('[data-tabs]');

    const onTabClick = (evt) => {
        if (evt.target.tagName.toLowerCase() === 'a') {
            switchToCategory(evt.target.dataset.tab);
        }
    };

    tabsElement.addEventListener('click', onTabClick);

    let currentCategory;

    const showCategory = (category) => {
        const newTab = document.querySelector(`[data-tab="${category}"]`);
        const newCategoryElement = document.querySelector(`[data-category="${category}"]`);

        newTab.classList.add(ACTIVE_TAB_CLASS_NAME);
        newCategoryElement.dataset.categoryActive = '';
        document.body.id = category;

        currentCategory = category;
    };

    const hideCategory = () => {
        const oldTab = document.querySelector(`[data-tab="${currentCategory}"]`);
        const oldCategoryElement = document.querySelector(`[data-category="${currentCategory}"]`);

        oldTab.classList.remove(ACTIVE_TAB_CLASS_NAME);
        delete oldCategoryElement.dataset.categoryActive;
    };

    const scrollToQuestion = (questionElement) => {
        questionElement.scrollIntoView({block: 'center'});
    }

    const switchToCategory = (category) => {
        if (!currentCategory) {
            showCategory(category);
            return;
        }

        if (currentCategory === category) {
            return;
        }

        hideCategory();
        showCategory(category);
    };

    const initCategory = () => {
        const hashArray = window.location.hash.substring(1).split('?');
        let newCategory = ''
        let questionId = '';

        if (hashArray.length === 1 ) {
            newCategory = hashArray[0];
        }

        if (hashArray.length === 2) {
            newCategory = hashArray[0];
            questionId = hashArray[1];
            
        }

        if (CATEGORIES.has(newCategory)) {
            switchToCategory(newCategory);
            if (questionId) {
                const questionElement = document.getElementById(questionId);
                if (questionElement) {
                    toggleAnswer(questionElement.closest('[data-question]'), true);
                }
            }
            return;
        }

        switchToCategory(DEFAULT_CATEGORY);
        window.location.hash = DEFAULT_CATEGORY;
    };


    const questionsElements = document.querySelectorAll('[data-questions]');
    let currentQuestionElement = null;

    const onQuestionClick = (evt) => {
        if (evt.target.dataset.questionToggle !== undefined) {
            toggleAnswer(evt.target.closest('[data-question]'));
        }
    };

    questionsElements.forEach(element => {
        element.addEventListener('click', onQuestionClick);
    });

    const resetQuestion = (element) => {
        const containerElement = element
            .querySelector('[data-content-container]');

        delete element.dataset.questionActive;
        containerElement.style.height = '0';
    };

    const toggleAnswer = (element, isNeededToScroll) => {
        if (currentQuestionElement === element) {
            resetQuestion(currentQuestionElement);
            currentQuestionElement = null;
            return;
        }

        if (currentQuestionElement) {
            resetQuestion(currentQuestionElement);
        }

        element.dataset.questionActive = '';

        const containerElement = element
            .querySelector('[data-content-container]');
        const contentHeight = containerElement.firstElementChild.clientHeight;

        containerElement.style.height = `${contentHeight}px`;
        currentQuestionElement = element;

        if (isNeededToScroll) {
            setTimeout(() => {
                scrollToQuestion(element);
                element.classList.toggle('questions__item--highlighted');
                setTimeout(() => {
                    element.classList.toggle('questions__item--highlighted');
                }, 4000)
            }, 300);
            
        }
    };
    initCategory();
})();
